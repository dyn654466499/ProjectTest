package com.daemon.interfaces;

import android.os.Message;

public interface ViewChangeListener {
	public void onViewChange(final Message msg);
}
