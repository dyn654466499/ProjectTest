package com.daemon.interfaces;

/**
 * 命令模式接口
 * @author 邓耀宁
 *
 */
public interface Commands {
    public void executeCommand();
}
