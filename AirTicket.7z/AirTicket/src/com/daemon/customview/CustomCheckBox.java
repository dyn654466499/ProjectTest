package com.daemon.customview;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.widget.CheckBox;

public class CustomCheckBox extends CheckBox{

	public CustomCheckBox(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void setButtonDrawable(Drawable d) {
		// TODO Auto-generated method stub
		super.setButtonDrawable(d);
	}

	@Override
	public void setButtonDrawable(int resId) {
		// TODO Auto-generated method stub
		super.setButtonDrawable(resId);
	}

	
}
